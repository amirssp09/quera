// Your code here

document.addEventListener('DOMContentLoaded', () => {
    const box = document.getElementById('moving-box');
    const toggleButton = document.getElementById('toggle-animation');
    let isAnimating = false;
    let animationInterval;
    let currentPosition = 0;
    const moveDistance = 300; // فاصله حرکت به پیکسل
    const animationDuration = 2000; // مدت زمان حرکت به میلی‌ثانیه
    const steps = 60; // تعداد فریم‌ها در ثانیه

    toggleButton.addEventListener('click', () => {
        if (isAnimating) {
            // متوقف کردن انیمیشن
            clearInterval(animationInterval);
            isAnimating = false;
            toggleButton.textContent = 'Start Animation';
        } else {
            // شروع انیمیشن
            isAnimating = true;
            toggleButton.textContent = 'Pause Animation';
            startAnimation();
        }
    });

    function startAnimation() {
        const stepSize = moveDistance / (animationDuration / (1000 / steps));
        let direction = 1; // 1 برای حرکت به راست، -1 برای حرکت به چپ

        animationInterval = setInterval(() => {
            if (direction === 1) {
                currentPosition += stepSize;
                if (currentPosition >= moveDistance) {
                    currentPosition = moveDistance;
                    direction = -1; // تغییر جهت به چپ
                }
            } else {
                currentPosition -= stepSize;
                if (currentPosition <= 0) {
                    currentPosition = 0;
                    direction = 1; // تغییر جهت به راست
                }
            }

            box.style.left = `${currentPosition}px`;
        }, 1000 / steps); // تنظیم فریم‌ریت
    }
});



s = input().strip()
t = input().strip()
n = int(input())

if len(s) > n:
    print("-1")
elif t in s:
    print("-1")
else:
    result = s
    remaining_length = n - len(s)
    result += "a" * remaining_length

    if t in result:
        result = result.replace("a", "b", 1)

    if t in result:
        print("-1")
    else:
        print(result)
